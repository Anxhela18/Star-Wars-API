<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>SWAPI Demo</title>
  
    </head>
    <body>
        <header>

            <h1>Star Wars API</h1>
        </header>

        <?php include '../db/conn.php'; ?>

        <nav id="nav"></nav></br>
        <form method="GET">
            <!--            <main id="main" name="main"></main>-->
            <button id="vehicles" class="btn" style="text-align: center" type="button">Vehicles Insert</button>

        </form>
        <span id="insert"></span>
        <span>How many passengers are in Vehicles ?</span>
        <button type="button" id="Ans1">Answer</button>


        <?php
        $sql = "Select * from vehicles";
        $res = mysqli_query($conn, $sql);
        $sum = 0;
        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_array($res)) {
                $passengers = $row['passengers'];
                $crewanswer = $row['crew'];
                $sum += $passengers;
            }
        }
        ?>

        <span id="Res1" style="display: none"><?php echo $sum; ?></span>



<!--        <script src="../js/app.js" defer></script>-->

        <table class="table">

            <thead>

            <th data-field = "name"> name</th>

            <th data-field = "model" data-sortable = "true">model</th>

            <th data-field = "manufacturer" data-sortable = "true">manufacturer</th>

            <th data-field = "cost_in_credits" data-sortable = "true">cost_in_credits</th>
            <th data-field = "length" data-sortable = "true">length</th>
            <th data-field = "max_atmosphering_speed">max_atmosphering_speed</th>
            <th data-field = "crew" data-sortable = "true">crew</th>

            <th data-field = "passengers" data-sortable = "true">passengers</th>

            <th data-field = "cargo_capacity" data-sortable = "true">cargo_capacity</th>
            <th data-field = "consumables" data-sortable = "true">consumables</th>
            <th data-field = "vehicle_class">vehicle_class</th>


            <th data-field = "films" data-sortable = "true">films</th>
            <th data-field = "created" data-sortable = "true">created</th>
            <th data-field = "edited">edited</th>

        </thead>

        <tbody>
            <?php
            $sql = "select * from vehicles ";
            $res = mysqli_query($conn, $sql);
            foreach ($res as $elem) {
                ?>
                <tr>

                    <td>   <?php echo $elem['name']; ?>  </td>
                    <td>   <?php echo $elem['model']; ?>  </td>
                    <td>   <?php echo $elem['manufacturer']; ?>  </td>
                    <td>   <?php echo $elem['cost_in_credits']; ?>  </td>
                    <td>   <?php echo $elem['length']; ?>  </td>
                    <td>   <?php echo $elem['max_atmosphering_speed']; ?>  </td>
                    <td >           <input id="crew<?php echo $elem['id']; ?>"   value="<?php echo $elem['crew']; ?>" /></td>

                    <td>   <?php echo $elem['passengers']; ?>  </td>
                    <td>   <?php echo $elem['cargo_capacity']; ?>  </td>
                    <td>   <?php echo $elem['consumables']; ?>  </td>
                    <td>   <?php echo $elem['vehicle_class']; ?>  </td>
                    <td>   <?php echo $elem['films']; ?>  </td>
                    <td>   <?php echo $elem['created']; ?>  </td>
                    <td>   <?php echo $elem['edited']; ?>  </td>
                    <td><button  id="increment<?php echo $elem['id']; ?>"   type="button"   >Increment Crew</button></td>
                    <td><button id="decrement<?php echo $elem['id']; ?>" type="button">Decrement Crew</button></td>
                </tr>





            <script>


                function increment() {

                    var value = parseInt(document.getElementById('crew<?php echo $elem['id']; ?>').value, 10);
                    value = isNaN(value) ? 0 : value;
                    value++;
                    document.getElementById('valCrew<?php echo $elem['id']; ?>').value = value;
                    //                var element = $('#crew<?php //echo $elem['id'];                 ?>').val();
                    //                console.log(++element);


                }
                $(document).ready(function () {

                    $("#Ans1").on('click', function (e) {
                        $('#Res1').css("display", "block");
                    });




                    $('#increment<?php echo $elem['id']; ?>').click(function add() {
                        var $crew = $("#crew<?php echo $elem['id']; ?>");
                        var a = $crew.val();

                        a++;

                        $crew.val(a);
                    });


                    $('#decrement<?php echo $elem['id']; ?>').click(function subst() {
                        var $crew = $("#crew<?php echo $elem['id']; ?>");
                        var b = $crew.val();
                        if (b >= 1) {
                            b--;
                            $crew.val(b);
                        }
                    });


                });




            </script>

        <?php } ?>
    </tbody>


</table>

<?php ?>
</body>


<script>
    $(document).ready(function () {

        $("#vehicles").on('click', function (e) {
            e.preventDefault();
            $.ajax({url: "https://swapi.dev/api/vehicles/",
                dataType: "json",
                type: "GET",
                cache: false,
                contentType: "application/json",
                success: function (data) {

                    $.ajax({
                        url: '../test.php',
                        method: 'POST',
                        dataType: 'json',
                        processData: false,
                        contentType: 'application/json',
                        data: JSON.stringify({
                            "data": data

                        }),
                        success: function (data) {
                            $('#insert').html(data);
                        }

                    });
                }

            });
        });
    });
</script>
</html>
