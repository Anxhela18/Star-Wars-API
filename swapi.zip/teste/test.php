<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


//$json = file_get_contents('php://input');
//$entity= json_decode($json, TRUE);
//if (isset($_POST['data'])) {

$data = json_decode(stripslashes(file_get_contents('php://input')));
$data->{'data'};
$dataArray = json_decode(json_encode($data), True);

include './db/conn.php';

foreach ($dataArray as $id => $elm) {

    foreach ($elm['results'] as $k) {

        $name = $k['name'];
        $model = $k['model'];
        $manufacturer = $k['manufacturer'];
        $cost_in_credits = $k['cost_in_credits'];
        $length = $k['length'];
        $max_atmosphering_speed = $k['max_atmosphering_speed'];
        $crew = $k['crew'];
        $passengers = $k['passengers'];
        $cargo_capacity = $k['cargo_capacity'];
        $consumables = $k['consumables'];
        $vehicle_class = $k['vehicle_class'];
        $films = $k['films'];
        $created = $k['created'];
        $edited = $k['edited'];

        foreach ($k['films'] as $elm) {




            $sql = " INSERT INTO vehicles (name,model,manufacturer,cost_in_credits ,   length,max_atmosphering_speed,crew,passengers, cargo_capacity, consumables,vehicle_class,films,created,edited)
      VALUES ( '$name', '$model', '$manufacturer', '$cost_in_credits' , '$length' , '$max_atmosphering_speed', '$crew' , '$passengers' ,     '$cargo_capacity'      ,  '$consumables'  , '$vehicle_class', '$elm' ,   '$created' ,  '$edited' );";

            $result = mysqli_query($conn, $sql);

            if ($result === TRUE) {
                $msg = 'inserted';
            } else {
                $msg = mysqli_error($conn);
            }
        }
    }
}

echo $msg;
