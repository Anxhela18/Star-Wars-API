<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$dbhost = 'localhost:3308';
$user = 'root';
$password = '';
$db = 'newTest';
// Create connection
$conn = new mysqli($dbhost, $user, $password, $db);

//
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    
}



